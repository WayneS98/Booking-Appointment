﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace XBCAD_WPF
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-I39EV2R\SQLSERVERCLDV;Initial Catalog=xbcadDb;Integrated Security=True");

        public Register()
        {
            InitializeComponent();
            ComboBox1.Items.Add("Tutor");
            ComboBox1.Items.Add("Student");

            try
            {
                SqlCommand sqlCmd = new SqlCommand("SELECT ModuleID FROM ModuleTbl", con);
                con.Open();
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                    ComboBox2.Items.Add(sqlReader["ModuleID"].ToString());
                }

                sqlReader.Close();
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Error occured!");
            }
            con.Close();

            cbCity.Items.Add("Johannesburg");
            cbCity.Items.Add("Pretoria");
            cbCity.Items.Add("Durban");
            cbCity.Items.Add("Cape Town");
            

        }

        private void ComboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if(ComboBox1.Text == "Student")
                {
                    SqlCommand sqlCmd = new SqlCommand("Insert into StudentTbl values ('"+txtUsername.Text+ "' , '" + txtPassword.Text + "', '" + txtEmail.Text + "' , '"+cbCity.Text.ToString()+"')", con);
                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Created Successfully");

                    MainWindow window = new MainWindow();
                    window.Show();
                    this.Close();
                }
                else if (ComboBox1.Text == "Tutor")
                {
                    SqlCommand sqlCmd = new SqlCommand("Insert into TutorTbl values ('" + txtUsername.Text + "' , '" + txtEmail.Text + "', '" + txtPassword.Text + "' , '" + ComboBox2.Text.ToString() + "' , '" + cbCity.Text.ToString() + "' )", con);
                    con.Open();
                    sqlCmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Created Successfully");

                    MainWindow window = new MainWindow();
                    window.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }

            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }

        private void btnGoback_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }
    }
}

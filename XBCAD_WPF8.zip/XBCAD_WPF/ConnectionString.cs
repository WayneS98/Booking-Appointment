﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace XBCAD_WPF
{
    class ConnectionString
    {
        public SqlConnection GetCon()
        {
            SqlConnection con = new SqlConnection("");
            con.ConnectionString = @"Data Source=DESKTOP-I39EV2R\SQLSERVERCLDV;Initial Catalog=xbcadDb;Integrated Security=True";
            return con;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace XBCAD_WPF
{
    /// <summary>
    /// Interaction logic for CancelWindow.xaml
    /// </summary>
    public partial class CancelWindow : Window
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-I39EV2R\SQLSERVERCLDV;Initial Catalog=xbcadDb;Integrated Security=True");
        int UserID2;
        public CancelWindow(string UserID)
        {
            InitializeComponent();

            UserID2 = Int32.Parse(UserID);
            try
            {
                
                string query = "Select LessonDate as [Lesson Date], ModuleID as [Module Code] From LessonTbl " +
                    "            WHERE '" + UserID + "' = StudentID ";
                con.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, con);
                DataTable dtbl = new DataTable("Lessons");
                sqlDa.Fill(dtbl);
                Datagrid.ItemsSource = dtbl.DefaultView;
                con.Close();

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }


            try
            {
                SqlCommand sqlCmd = new SqlCommand("SELECT LessonDate FROM LessonTbl WHERE StudentID = '"+UserID2+"'", con);
                con.Open();
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                    cbLessons.Items.Add(sqlReader["LessonDate"].ToString());
                }

                sqlReader.Close();
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            

            try
            {
                con.Open();

                if(cbLessons.SelectedItem == null)
                {
                    MessageBox.Show("Please select a lesson date");
                }
                else
                {
                    DateTime date = DateTime.Parse(cbLessons.Text);
                    SqlCommand command = new SqlCommand("Update LessonTbl SET LessonStatus = 'CANCELLED' WHERE '" + date + "' = LessonDate AND StudentID = '" + UserID2 + "'", con);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Lesson has been cancelled");
                }
                
                con.Close();
;            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }


        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

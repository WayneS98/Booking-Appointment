﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace XBCAD_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-I39EV2R\SQLSERVERCLDV;Initial Catalog=xbcadDb;Integrated Security=True");

        public MainWindow()
        {
            InitializeComponent();
            ComboBox1.Items.Add("Tutor");
            ComboBox1.Items.Add("Student");
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ComboBox1.Text == "Student")
                {
                    SqlCommand sqlCmd = new SqlCommand("Select * From StudentTbl Where StudentName = '" + txtUsername.Text + "' and StudentPassword = '" + txtPassword.Text + "' ", con);
                    con.Open();
                    SqlDataReader reader;
                    reader = sqlCmd.ExecuteReader();

                    if (reader.Read())
                    {


                        

                        Student student = new Student(txtUsername.Text);
                        student.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Name or password was incorrect");
                        txtUsername.Text = "";
                        txtPassword.Text = "";

                    }
                    
                    
                }
                else if (ComboBox1.Text == "Tutor")
                {
                    SqlCommand sqlCmd = new SqlCommand("Select * From TutorTbl Where TutorName = '" + txtUsername.Text + "' and TutorPassword = '" + txtPassword.Text + "' ", con);
                    con.Open();
                    SqlDataReader reader;
                    reader = sqlCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        
                        Tutor tutor = new Tutor(txtUsername.Text);
                        tutor.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Name or password was incorrect");
                        txtUsername.Text = "";
                        txtPassword.Text = "";

                    }
                    
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }


            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

            con.Close();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            
            Register register = new Register();
            register.Show();
            this.Close();
        }
    }
}

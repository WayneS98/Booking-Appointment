﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace XBCAD_WPF
{
    /// <summary>
    /// Interaction logic for Tutor.xaml
    /// </summary>
    public partial class Tutor : Window
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-I39EV2R\SQLSERVERCLDV;Initial Catalog=xbcadDb;Integrated Security=True");
        string UsernameTutor;
        string UserID;
        public Tutor(string username)
        {
            InitializeComponent();

            UsernameTutor = username;

            string command1 = "Select TutorID From TutorTbl where TutorName = '" + UsernameTutor + "'";
            SqlCommand cmd = new SqlCommand(command1, con);
            con.Open();
            SqlDataReader DR1 = cmd.ExecuteReader();
            if (DR1.Read())
            {
                UserID = DR1.GetValue(0).ToString();
            }
            DR1.Close();
            con.Close();

            //upcoming lessons 
            try
            { 

                string query = "Select LessonStatus as [Status], LessonDate as [Lesson Date], ModuleID as [Module Code] From LessonTbl " +
                    "            WHERE '" + UserID + "' = TutorID ";

                SqlDataAdapter sqlDa = new SqlDataAdapter(query, con);
                DataTable dtbl = new DataTable("Lessons");
                sqlDa.Fill(dtbl);
                DatagridLessons2.ItemsSource = dtbl.DefaultView;
                con.Close();

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }


            //populate Student name combo box
            try
            {
                string query = "Select distinct StudentTbl.StudentName " +
                    "  from ((LessonTbl Inner Join StudentTbl ON LessonTbl.StudentID = StudentTbl.StudentID)" +
                    "  INNER JOIN TutorTbl ON LessonTbl.TutorID = TutorTbl.TutorID) WHERE LessonTbl.TutorID = '" + UserID + "'; ";
                

                SqlCommand sqlCmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                    cbStudentName.Items.Add(sqlReader["StudentName"].ToString());
                }

                sqlReader.Close();
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }



        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "Select TutorTbl.TutorName as [Tutor Name], StudentTbl.StudentName as [Student Name],LessonTbl.ModuleID as [Module Code],LessonTbl.LessonDate as [Lesson Date] , LessonTbl.LessonStatus as [Status]" +
                    "  from ((LessonTbl Inner Join StudentTbl ON LessonTbl.StudentID = StudentTbl.StudentID)" +
                    "  INNER JOIN TutorTbl ON LessonTbl.TutorID = TutorTbl.TutorID) WHERE '" + UserID + "' = LessonTbl.TutorID; ";
                con.Open();

                SqlDataAdapter sqlDa = new SqlDataAdapter(query, con);
                DataTable dtbl = new DataTable("Lessons");
                sqlDa.Fill(dtbl);
                gridLessons.ItemsSource = dtbl.DefaultView;

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
            con.Close();

        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnCancel_Click_1(object sender, RoutedEventArgs e)
        {
            CancelWindow2 cancelWindow = new CancelWindow2(UserID);
            cancelWindow.Show();
        }

        private void btnEmail_Click(object sender, RoutedEventArgs e)
        {
            string query = "Select StudentEmail FROM StudentTbl Where StudentName = '"+cbStudentName.Text.ToString()+"'";
            SqlCommand sqlCmd = new SqlCommand(query, con);
            con.Open();

            SqlDataReader DR1 = sqlCmd.ExecuteReader();
            if (DR1.Read())
            {
                string StudentEmail = DR1.GetValue(0).ToString();
                MessageBox.Show(StudentEmail);
            }
            else
            {
                MessageBox.Show("They have no email saved");
            }
            DR1.Close();
            con.Close();
        }
    }
}

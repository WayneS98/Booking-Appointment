﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace XBCAD_WPF
{
    /// <summary>
    /// Interaction logic for Student.xaml
    /// </summary> 
    public partial class Student : Window
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-I39EV2R\SQLSERVERCLDV;Initial Catalog=xbcadDb;Integrated Security=True");
        string UsernameStudent;
        string UserID;
        string TutorID;
        public Student(string username)
        {
            InitializeComponent();
             UsernameStudent = username;



            //populate module combo box
            try
            {
                SqlCommand sqlCmd = new SqlCommand("SELECT ModuleID FROM ModuleTbl", con);
                con.Open();
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                    cbModule.Items.Add(sqlReader["ModuleID"].ToString());
                }

                sqlReader.Close();
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


            //populate city combo box
            cbCity.Items.Add("Johannesburg");
            cbCity.Items.Add("Pretoria");
            cbCity.Items.Add("Durban");
            cbCity.Items.Add("Cape Town");


            try
            {
                SqlCommand sqlCmd = new SqlCommand("SELECT TutorName FROM TutorTbl where ModuleID = '"+cbModule.Text+"'", con);
                con.Open();
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                    cbTutor.Items.Add(sqlReader["TutorName"].ToString());
                }

                sqlReader.Close();
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error occured!");
            }
            


            //upcoming lessons 
            try
            {
                //get Student ID
                string command1 = "Select StudentID From StudentTbl where StudentName = '" + UsernameStudent + "'";
                SqlCommand cmd = new SqlCommand(command1, con);
                con.Open();
                SqlDataReader DR1 = cmd.ExecuteReader();
                if (DR1.Read())
                {
                    UserID = DR1.GetValue(0).ToString();
                }
                DR1.Close();


                string query = "Select LessonStatus as [Status], LessonDate as [Lesson Date], ModuleID as [Module Code] From LessonTbl " +
                    "            WHERE '"+UserID+"' = StudentID ";
                
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, con);
                DataTable dtbl = new DataTable("Lessons");
                sqlDa.Fill(dtbl);
                DatagridLessons2.ItemsSource = dtbl.DefaultView;
                con.Close();

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
            
            


        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            //get Student ID
            string command1 = "Select StudentID From StudentTbl where StudentName = '" + UsernameStudent + "'";
            SqlCommand cmd = new SqlCommand(command1, con);
            con.Open();
            SqlDataReader DR1 = cmd.ExecuteReader();
            if (DR1.Read())
            {
                 UserID = DR1.GetValue(0).ToString();
            }
            DR1.Close();

            
            int StudentID = Int32.Parse(UserID);
            
            //get tutor ID
            string command2 = "Select TutorID From TutorTbl where TutorName = '" + cbTutor.Text + "'";
            SqlCommand cmd2 = new SqlCommand(command2, con);
            SqlDataReader DR2 = cmd2.ExecuteReader();
            if (DR2.Read())
            {
                TutorID = DR2.GetValue(0).ToString();
            }
            DR2.Close();

            con.Close();
            int TutorID2 = Int32.Parse(TutorID);

            //create Lesson
            string query = "Insert into LessonTbl values ('" + TutorID2 + "' , '" + UserID + "' , '" + cbModule.SelectedItem.ToString() + "' , '" + dpDate.SelectedDate + "' , 'BOOKED')";

            SqlCommand command = new SqlCommand(query,con);
            con.Open();

            try
            {
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Lesson Sucessfully Booked \n Please note: All lessons are paid for with cash");
            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = "Select StudentTbl.StudentName as [Student Name], TutorTbl.TutorName as [Tutor Name], TutorTbl.TutorEmail as [Tutor Email], LessonTbl.ModuleID as [Module Code],LessonTbl.LessonDate as [Lesson Date], LessonTbl.LessonStatus as [Lesson Status]" +
                    "  from ((LessonTbl Inner Join StudentTbl ON LessonTbl.StudentID = StudentTbl.StudentID)" +
                    "  INNER JOIN TutorTbl ON LessonTbl.TutorID = TutorTbl.TutorID) WHERE LessonTbl.StudentID = '"+ UserID + "'; "; 
                con.Open();
                
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, con);
                DataTable dtbl = new DataTable("Lessons");
                sqlDa.Fill(dtbl);
                gridLessons.ItemsSource = dtbl.DefaultView;

            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
            con.Close();

        }

        private void cbTutor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            


        }

        private void cbModule_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           

            
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {

            CancelWindow cancelWindow = new CancelWindow(UserID);
            cancelWindow.Show();
            


        }

        private void gridLessons_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnCancel_Click_1(object sender, RoutedEventArgs e)
        {
            CancelWindow cancelWindow = new CancelWindow(UserID);
            cancelWindow.Show();
        }

        private void btnSearchTutor_Click(object sender, RoutedEventArgs e)
        {
            cbTutor.Items.Clear();

            try
            {
                SqlCommand sqlCmd = new SqlCommand("SELECT TutorName FROM TutorTbl where ModuleID = '" + cbModule.Text + "' AND TutorCity = '"+cbCity.Text+"'", con);
                con.Open();
                SqlDataReader sqlReader = sqlCmd.ExecuteReader();

                while (sqlReader.Read())
                {
                    cbTutor.Items.Add(sqlReader["TutorName"].ToString());
                }
                sqlReader.Close();

                SqlCommand sqlCmd2 = new SqlCommand("SELECT TutorName FROM TutorTbl where ModuleID = '" + cbModule.Text + "' AND TutorCity = '" + cbCity.Text + "'", con); 
                SqlDataReader sqlReader2 = sqlCmd2.ExecuteReader();

                if (sqlReader2.Read())
                {
                    MessageBox.Show("Tutors Found");

                }
                else
                {
                    MessageBox.Show("No Tutors Found For This Module");
                }


                sqlReader2.Close();
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            con.Close();



        }
    }
}
